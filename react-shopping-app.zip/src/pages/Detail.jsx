// 商品詳細について

const number = [
    { Capname: "1" },
    { Capname: "2" },
    { Capname: "3" },
    { Capname: "4" },
    { Capname: "5" },
    { Capname: "6" },
    { Capname: "7" },
    { Capname: "8" },
    { Capname: "9" },
    { Capname: "0" }
]

const alphabet = [
    { Capname: "A" },
    { Capname: "B" },
    { Capname: "C" },
    { Capname: "D" },
    { Capname: "E" },
    { Capname: "F" },
    { Capname: "G" },
    { Capname: "H" },
    { Capname: "I" },
    { Capname: "J" },
    { Capname: "K" },
    { Capname: "L" },
    { Capname: "M" },
    { Capname: "N" },
    { Capname: "O" },
    { Capname: "P" },
    { Capname: "Q" },
    { Capname: "R" },
    { Capname: "S" },
    { Capname: "T" },
    { Capname: "U" },
    { Capname: "V" },
    { Capname: "W" },
    { Capname: "X" },
    { Capname: "Y" },
    { Capname: "Z" }
]

// の印字がされたキーキャップです。
// キーキャップ「 」
//    {Capname:""},