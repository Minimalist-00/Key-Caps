// 殆どのページに共通するフッター

function Footer() {
    return (
        <div>

        </div>
    );
}

export default Footer;